Author: k0nsl (i.am@k0nsl.org)

This hook queries the database of stopforumspam.com and checks if the IP is listed or not (only upon registration). If it matches the user is informed and the application exits.

I only wrapped this into a useful hook, the main credit belongs to Maurice of FixingTheWeb.com
